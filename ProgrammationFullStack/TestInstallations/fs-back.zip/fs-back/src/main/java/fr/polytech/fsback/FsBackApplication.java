package fr.polytech.fsback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FsBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(FsBackApplication.class, args);
	}

}
