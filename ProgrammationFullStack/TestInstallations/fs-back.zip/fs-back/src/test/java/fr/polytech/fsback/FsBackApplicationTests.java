package fr.polytech.fsback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FsBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
